package com.example.emailotpverification.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "mst_person_info")
public class PersonInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "person_id")
    private Long personId;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "is_basic_details_submission")
    private Boolean isBasicDetailsSubmission = false;

    @Column(name = "status")
    private Integer status = 0;

    @Column(name = "employee_id")
    private String employeeId;

    @OneToOne(mappedBy = "personInfo", fetch = FetchType.LAZY)
    private ActivationRequest activationRequest;

    // ✅ FIXED RELATION
    @OneToOne(mappedBy = "personInfo", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private PersonBasicDetails basicDetails;

    public PersonInfo() {
    }

    public PersonInfo(Long id, Long personId, String firstName, String lastName, Boolean isBasicDetailsSubmission, Integer status, String employeeId, ActivationRequest activationRequest, PersonBasicDetails basicDetails) {
        this.id = id;
        this.personId = personId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.isBasicDetailsSubmission = isBasicDetailsSubmission;
        this.status = status;
        this.employeeId = employeeId;
        this.activationRequest = activationRequest;
        this.basicDetails = basicDetails;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Boolean getIsBasicDetailsSubmission() {
        return isBasicDetailsSubmission;
    }

    public void setIsBasicDetailsSubmission(Boolean basicDetailsSubmission) {
        isBasicDetailsSubmission = basicDetailsSubmission;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public ActivationRequest getActivationRequest() {
        return activationRequest;
    }

    public void setActivationRequest(ActivationRequest activationRequest) {
        this.activationRequest = activationRequest;
    }

    public PersonBasicDetails getBasicDetails() {
        return basicDetails;
    }

    public void setBasicDetails(PersonBasicDetails basicDetails) {
        this.basicDetails = basicDetails;
    }

    @Override
    public String toString() {
        return "PersonInfo{" +
                "id=" + id +
                ", personId=" + personId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", isBasicDetailsSubmission=" + isBasicDetailsSubmission +
                ", status=" + status +
                ", employeeId='" + employeeId + '\'' +
                ", activationRequest=" + activationRequest +
                ", basicDetails=" + basicDetails +
                '}';
    }


}