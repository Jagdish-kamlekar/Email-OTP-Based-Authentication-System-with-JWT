package com.example.emailotpverification.util;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class TwilioOtpService {

    @Value("${twilio.from-number}")
    private String fromNumber;


    public void sendMobileOtp(String to, String message) {

        String sanitizedFrom = fromNumber.trim();
        String sanitizedTo = to.trim();

        Message.creator(
                new PhoneNumber(sanitizedTo),      // To number (+91XXXXXXXXXX)
                new PhoneNumber(sanitizedFrom),
                message
        ).create();
    }
}
