package com.example.emailotpverification.entity;


import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "mst_auth_request")
public class ActivationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false, unique = true)
    private String contact;

    @Column
    private String password;

    @Column(name = "is_contact_verified")
    private Boolean isContactVerified = false;

    @Column(name = "is_email_verified")
    private Boolean isEmailVerified = false;

    @Column(name = "is_person_exist")
    private Boolean isPersonExist = false;

    @Column(name = "login_date")
    private Timestamp loginDate;

    @Column(name = "logout_date")
    private Timestamp logoutDate;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "person_id")
    private PersonInfo personInfo;

    public ActivationRequest() {
    }

    public ActivationRequest(Long id, String email, String contact, String password, Boolean isContactVerified, Boolean isEmailVerified, Boolean isPersonExist, Timestamp loginDate, Timestamp logoutDate, PersonInfo personInfo) {
        this.id = id;
        this.email = email;
        this.contact = contact;
        this.password = password;
        this.isContactVerified = isContactVerified;
        this.isEmailVerified = isEmailVerified;
        this.isPersonExist = isPersonExist;
        this.loginDate = loginDate;
        this.logoutDate = logoutDate;
        this.personInfo = personInfo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getIsContactVerified() {
        return isContactVerified;
    }

    public void setIsContactVerified(Boolean contactVerified) {
        isContactVerified = contactVerified;
    }

    public Boolean getIsEmailVerified() {
        return isEmailVerified;
    }

    public void setIsEmailVerified(Boolean emailVerified) {
        isEmailVerified = emailVerified;
    }

    public Boolean getIsPersonExist() {
        return isPersonExist;
    }

    public void setIsPersonExist(Boolean personExist) {
        isPersonExist = personExist;
    }

    public Timestamp getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Timestamp loginDate) {
        this.loginDate = loginDate;
    }

    public Timestamp getLogoutDate() {
        return logoutDate;
    }

    public void setLogoutDate(Timestamp logoutDate) {
        this.logoutDate = logoutDate;
    }

    public PersonInfo getPersonInfo() {
        return personInfo;
    }

    public void setPersonInfo(PersonInfo personInfo) {
        this.personInfo = personInfo;
    }

    @Override
    public String toString() {
        return "ActivationRequest{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", contact='" + contact + '\'' +
                ", password='" + password + '\'' +
                ", isContactVerified=" + isContactVerified +
                ", isEmailVerified=" + isEmailVerified +
                ", isPersonExist=" + isPersonExist +
                ", loginDate=" + loginDate +
                ", logoutDate=" + logoutDate +
                ", personInfo=" + personInfo +
                '}';
    }

}