package com.example.emailotpverification.service;

import java.util.concurrent.TimeUnit;

public interface RedisService {

    String get(String key);

    void clear(String key);

    void store(String key, String value, long expirationTime, TimeUnit timeUnit);

}
