package com.example.emailotpverification.util;

public class ApiResponse<T> {

    private boolean status;
    private Integer code;
    private String message;
    private T data;
    private Integer totalRecords;

    public ApiResponse() {}

    public ApiResponse(boolean status, Integer code, String message, T data, Integer totalRecords) {
        this.status = status;
        this.code = code;
        this.message = message;
        this.data = data;
        this.totalRecords = totalRecords;
    }

    // Static success response
    public static <T> ApiResponse<T> success(Integer code, String message, T data) {
        return new ApiResponse<>(true, code, message, data, null);
    }

    // Static failure response
    public static <T> ApiResponse<T> failure(Integer code, String message) {
        return new ApiResponse<>(false, code, message, null, null);
    }

    // Getters & Setters

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Integer getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(Integer totalRecords) {
        this.totalRecords = totalRecords;
    }
}