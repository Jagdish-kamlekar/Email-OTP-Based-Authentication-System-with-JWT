package com.example.emailotpverification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootApplication
public class EmailotpverificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailotpverificationApplication.class, args);
	}

}
