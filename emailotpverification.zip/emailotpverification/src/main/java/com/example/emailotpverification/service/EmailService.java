package com.example.emailotpverification.service;

import org.springframework.web.multipart.MultipartFile;

public interface EmailService {

    void sendOtpMessage(String email, String subject, String message1);

    void sendMail(String email, String subject, String message);

    void sendRegistrationEmail(String email);

    void sendMail(String to, String subject, String body, String[] cc, String[] bcc, MultipartFile[] attachments);

}
