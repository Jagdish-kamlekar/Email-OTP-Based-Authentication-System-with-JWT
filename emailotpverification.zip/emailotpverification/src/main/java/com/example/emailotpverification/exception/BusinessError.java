package com.example.emailotpverification.exception;

public class BusinessError {

    int code;
    String message;

    public BusinessError(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "BusinessError{" + "code=" + code + ", message=" + message + '}';
    }
}
