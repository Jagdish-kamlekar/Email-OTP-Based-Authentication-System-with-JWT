package com.example.emailotpverification.serviceimpl;

import com.example.emailotpverification.service.EmailService;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    //  Send OTP Email
    @Override
    public void sendOtpMessage(String email, String subject, String message1) {
        sendMail(email, subject, message1);
    }

    //  Simple Email (No CC/BCC/Attachment)
    @Override
    public void sendMail(String email, String subject, String message) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

            helper.setFrom(fromEmail);
            helper.setTo(email);
            helper.setSubject(subject);
            helper.setText(message, true);

            mailSender.send(mimeMessage);

            System.out.println("Simple Email Sent Successfully");

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Simple Email sending failed");
        }
    }

    // Registration Email (Custom Template)
    @Override
    public void sendRegistrationEmail(String email) {
        String subject = "Welcome to Our Platform 🎉";
        String body = "<h2>Registration Successful</h2>"
                + "<p>Thank you for registering with us.</p>";

        sendMail(email, subject, body);
    }

    // Advanced Email (CC, BCC, Attachments)
    @Override
    public void sendMail(String to, String subject, String body,
                         String[] cc, String[] bcc, MultipartFile[] attachments) {

        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setFrom(fromEmail);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(body, true);

            if (cc != null && cc.length > 0) {
                helper.setCc(cc);
            }

            if (bcc != null && bcc.length > 0) {
                helper.setBcc(bcc);
            }

            // Attachments handling
            if (attachments != null && attachments.length > 0) {
                for (MultipartFile file : attachments) {
                    helper.addAttachment(
                            file.getOriginalFilename(),
                            new ByteArrayResource(file.getBytes())
                    );
                }
            }

            mailSender.send(message);

            System.out.println("Advanced Email Sent Successfully");

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Advanced Email sending failed");
        }
    }
}