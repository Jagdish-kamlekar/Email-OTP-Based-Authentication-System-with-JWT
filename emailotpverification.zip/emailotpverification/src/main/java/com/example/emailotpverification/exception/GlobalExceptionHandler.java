package com.example.emailotpverification.exception;

import com.example.emailotpverification.util.Constant;
import com.example.emailotpverification.util.MsgConstant;
import io.jsonwebtoken.ExpiredJwtException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Log logger = LogFactory.getLog(GlobalExceptionHandler.class);

    // Handle validation errors for @Valid/@Validated DTOs
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<BusinessError> handleValidationExceptions(MethodArgumentNotValidException ex) {
        String firstErrorMessage = ex.getBindingResult().getFieldErrors().get(0).getDefaultMessage();
        // Create BusinessError object with only one validation error
        BusinessError businessError = new BusinessError(Constant.BAD_REQUEST, // Custom error code
                firstErrorMessage // Only return the first validation error message
        );
        return new ResponseEntity<>(businessError, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ExpiredJwtException.class)
    public ResponseEntity<BusinessError> handleExpiredJwtException(ExpiredJwtException ex) {
        HttpStatus status = HttpStatus.UNAUTHORIZED;
        BusinessError businessError = new BusinessError(Constant.LOGIN_TIME_OUT, MsgConstant.SESSION_TIME_OUT);
        ResponseEntity responseEntity = new ResponseEntity(businessError, status);
        logger.error("Exception is--:", ex);
        return responseEntity;
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<BusinessError> handleException(BusinessException ex) {
        BusinessError businessError;
        HttpStatus status = null;
        if (ex instanceof BusinessException) {
            if (((BusinessException) ex).getErrCode() == Constant.LOGIN_TIME_OUT) {
                status = HttpStatus.UNAUTHORIZED;
            } else {
                status = HttpStatus.valueOf(((BusinessException) ex).getErrCode());
            }
            businessError = new BusinessError(((BusinessException) ex).getErrCode(), ((BusinessException) ex).getErrMsg());
        } else {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            businessError = new BusinessError(Constant.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
        ResponseEntity responseEntity = new ResponseEntity(businessError, status);
        logger.error("Exception is--:", ex);
        return responseEntity;
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<BusinessError> handleException(Exception ex) {
        BusinessError businessError;
        HttpStatus status = null;
        if (ex instanceof BusinessException) {
            if (((BusinessException) ex).getErrCode() == Constant.LOGIN_TIME_OUT) {
                status = HttpStatus.UNAUTHORIZED;
            } else {
                status = HttpStatus.valueOf(((BusinessException) ex).getErrCode());
            }
            businessError = new BusinessError(((BusinessException) ex).getErrCode(), ((BusinessException) ex).getErrMsg());
        } else {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            businessError = new BusinessError(Constant.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
        ResponseEntity responseEntity = new ResponseEntity(businessError, status);
        logger.error("Exception is--:", ex);
        return responseEntity;
    }

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<BusinessError> handleBadCredentialsException(BadCredentialsException ex) {
        BusinessError businessError = new BusinessError(Constant.UNAUTHORIZED, MsgConstant.INVALID_CREDENTIALS);
        logger.error("BadCredentialsException caught: ", ex);
        return new ResponseEntity<>(businessError, HttpStatus.UNAUTHORIZED);
    }

}
