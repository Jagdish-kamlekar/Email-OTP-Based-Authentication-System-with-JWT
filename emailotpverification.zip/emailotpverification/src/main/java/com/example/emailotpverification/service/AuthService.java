package com.example.emailotpverification.service;

import com.example.emailotpverification.dto.*;

import java.util.List;

public interface AuthService {

    ActivationRequestDTO register(ActivationRequestDTO activationRequestDTO);

    ActivationRequestDTO verifyOtp(ActivationRequestDTO activationRequestDTO);

    String login(String username, String password);

    void saveBasicDetails(BasicDetailsDTO basicDetailsDTO);

    ProfileResponseDTO getProfile();

    String refreshToken(String authHeader);

    void generateResetPasswordURL(String data);

    void updatePassword(String token, String newPassword);
}