package com.example.emailotpverification.repository;

import com.example.emailotpverification.dto.AllUsersResponseDTO;
import com.example.emailotpverification.entity.ActivationRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ActivationRequestRepository extends JpaRepository<ActivationRequest, Long> {

    Optional<ActivationRequest> findByEmailOrContact(String email, String contact);

    Optional<ActivationRequest> findByEmail(String email);

    boolean existsByEmailOrContact(String email, String contact);

    @Query("""
    SELECT new com.example.emailotpverification.dto.AllUsersResponseDTO(
        a.email,
        a.contact,
        p.id,
        b.id,
        p.isBasicDetailsSubmission
    )
    FROM ActivationRequest a
    LEFT JOIN a.personInfo p
    LEFT JOIN p.basicDetails b
""")
    List<AllUsersResponseDTO> getAllUsers();

    @Query("SELECT a FROM ActivationRequest a WHERE a.email = :data OR a.contact = :data")
    Optional<ActivationRequest> findByEmailOrContact(@Param("data") String data);

}