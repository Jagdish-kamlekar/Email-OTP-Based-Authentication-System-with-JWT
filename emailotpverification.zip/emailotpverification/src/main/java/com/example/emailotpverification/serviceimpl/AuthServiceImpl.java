package com.example.emailotpverification.serviceimpl;

import com.example.emailotpverification.dto.*;
import com.example.emailotpverification.entity.ActivationRequest;
import com.example.emailotpverification.entity.PersonBasicDetails;
import com.example.emailotpverification.entity.PersonInfo;
import com.example.emailotpverification.exception.BusinessException;
import com.example.emailotpverification.repository.ActivationRequestRepository;
import com.example.emailotpverification.repository.PersonBasicDetailsRepository;
import com.example.emailotpverification.repository.PersonInfoRepository;
import com.example.emailotpverification.service.AuthService;
import com.example.emailotpverification.service.EmailService;
import com.example.emailotpverification.service.RedisService;
import com.example.emailotpverification.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.concurrent.TimeUnit;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    @Lazy
    private ActivationRequestRepository activationRequestRepository;

    @Autowired
    @Lazy
    private PersonInfoRepository personInfoRepository;

    @Autowired
    @Lazy
    private PersonBasicDetailsRepository personBasicDetailsRepository;

    @Autowired
    @Lazy
    private RedisService redisService;

    @Autowired
    @Lazy
    private EmailService emailService;

    @Autowired
    @Lazy
    private TwilioOtpService twilioService;

    @Autowired
    @Lazy
    private JwtUtil jwtUtil;

    @Autowired
    @Lazy
    private PasswordEncoder passwordEncoder;


    @Override
    public ActivationRequestDTO register(ActivationRequestDTO activationRequestDTO) {
        try {

            if (activationRequestRepository.existsByEmailOrContact(
                    activationRequestDTO.getEmail(),
                    activationRequestDTO.getContact())) {
                throw new BusinessException(Constant.BAD_REQUEST, MsgConstant.USER_ALREADY_EXISTS);
            }

            ActivationRequest activationRequest = new ActivationRequest();
            activationRequest.setEmail(activationRequestDTO.getEmail());
            activationRequest.setContact(activationRequestDTO.getContact());
            activationRequest.setPassword(passwordEncoder.encode(activationRequestDTO.getPassword()));
            activationRequest.setIsEmailVerified(false);
            activationRequest.setIsContactVerified(false);
            activationRequest.setIsPersonExist(false);

            activationRequestRepository.save(activationRequest);

            redisService.store(
                    MsgConstant.TEMP_PASSWORD_PREFIX + activationRequestDTO.getEmail(),
                    activationRequestDTO.getPassword(),
                    MsgConstant.OTP_EXPIRY,
                    TimeUnit.MINUTES
            );

            sendOtp(activationRequestDTO);

            activationRequestDTO.setEmailVerified(false);
            activationRequestDTO.setContactVerified(false);

            return activationRequestDTO;

        } catch (BusinessException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new BusinessException(Constant.INTERNAL_SERVER_ERROR, "Error during registration");
        }
    }

    @Async
    private void sendOtp(ActivationRequestDTO activationRequestDTO) {
        try {

            String emailOtp = OtpUtil.generateOtp();
            String mobileOtp = OtpUtil.generateOtp();

            String contact = activationRequestDTO.getContact().startsWith("+91")
                    ? activationRequestDTO.getContact()
                    : "+91" + activationRequestDTO.getContact();

            redisService.store(
                    MsgConstant.EMAIL_PREFIX + activationRequestDTO.getEmail(),
                    emailOtp,
                    MsgConstant.OTP_EXPIRY,
                    TimeUnit.MINUTES);

            redisService.store(
                    MsgConstant.MOBILE_PREFIX + contact,
                    mobileOtp,
                    MsgConstant.OTP_EXPIRY,
                    TimeUnit.MINUTES);

            String emailBody = buildOtpEmail(activationRequestDTO.getEmail(), emailOtp);

            emailService.sendMail(
                    activationRequestDTO.getEmail(),
                    "🔐 OTP Verification",
                    emailBody,
                    null,
                    null,
                    null
            );

            twilioService.sendMobileOtp(contact, "OTP: " + mobileOtp);

            System.out.println("Email OTP: " + emailOtp);
            System.out.println("Mobile OTP: " + mobileOtp);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public ActivationRequestDTO verifyOtp(ActivationRequestDTO activationRequestDTO) {
        try {

            String contact = activationRequestDTO.getContact().startsWith("+91")
                    ? activationRequestDTO.getContact()
                    : "+91" + activationRequestDTO.getContact();

            String storedEmailOtp = redisService.get(
                    MsgConstant.EMAIL_PREFIX + activationRequestDTO.getEmail());

            String storedMobileOtp = redisService.get(
                    MsgConstant.MOBILE_PREFIX + contact);

            if (storedEmailOtp == null ||
                    !storedEmailOtp.equals(activationRequestDTO.getEmailOtp())) {
                throw new BusinessException(Constant.BAD_REQUEST, MsgConstant.INVALID_EMAIL_OTP);
            }

            if (storedMobileOtp == null ||
                    !storedMobileOtp.equals(activationRequestDTO.getContactOtp())) {
                throw new BusinessException(Constant.BAD_REQUEST, MsgConstant.INVALID_MOBILE_OTP);
            }

            ActivationRequest activationRequest = activationRequestRepository
                    .findByEmailOrContact(
                            activationRequestDTO.getEmail(),
                            activationRequestDTO.getContact())
                    .orElseThrow(() ->
                            new BusinessException(Constant.NOT_FOUND, MsgConstant.USER_NOT_FOUND));

            activationRequest.setIsEmailVerified(true);
            activationRequest.setIsContactVerified(true);
            activationRequest.setIsPersonExist(true);

            PersonInfo personInfo = new PersonInfo();
            personInfo.setIsBasicDetailsSubmission(false);

            personInfo = personInfoRepository.save(personInfo);

            activationRequest.setPersonInfo(personInfo);
            activationRequestRepository.save(activationRequest);

            String rawPassword = redisService.get(
                    MsgConstant.TEMP_PASSWORD_PREFIX + activationRequestDTO.getEmail());

            sendWelcomeEmail(activationRequest, rawPassword);

            redisService.clear(MsgConstant.EMAIL_PREFIX + activationRequestDTO.getEmail());
            redisService.clear(MsgConstant.MOBILE_PREFIX + contact);
            redisService.clear(MsgConstant.TEMP_PASSWORD_PREFIX + activationRequestDTO.getEmail());

            String token;
            try {
                token = jwtUtil.generateToken(
                        activationRequest.getEmail(),
                        personInfo.getId(),
                        false
                );
            } catch (Exception e) {
                e.printStackTrace();
                throw new BusinessException(Constant.INTERNAL_SERVER_ERROR, "JWT generation failed");
            }


            ActivationRequestDTO responseDTO = new ActivationRequestDTO();
            responseDTO.setEmail(activationRequest.getEmail());
            responseDTO.setContact(activationRequest.getContact());
            responseDTO.setJwtToken(token);
            responseDTO.setEmailVerified(true);
            responseDTO.setContactVerified(true);

            return responseDTO;

        } catch (BusinessException ex) {
            throw ex;
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new BusinessException(Constant.INTERNAL_SERVER_ERROR, "Error during OTP verification");
        }
    }

    private void sendWelcomeEmail(ActivationRequest user, String rawPassword) {
        try {

            String body = String.format("""
    <html>
    <body style="margin:0;padding:0;background:#f4f6f8;font-family:Arial">

        <div style="max-width:500px;margin:40px auto;background:#ffffff;
                    border-radius:12px;padding:30px;
                    box-shadow:0 5px 15px rgba(0,0,0,0.1);">

            <h2 style="color:#4CAF50;text-align:center;">
                🎉 Welcome to YourApp
            </h2>

            <p>Hello <b>%s</b>,</p>

            <p>Your account has been <b>successfully activated</b>.</p>

            <div style="background:#f9f9f9;padding:15px;
                        border-radius:8px;margin:20px 0;">
                <p><b>Email:</b> %s</p>
                <p><b>Password:</b> %s</p>
            </div>

        </div>
    </body>
    </html>
    """, user.getEmail(), user.getEmail(), rawPassword);

            emailService.sendMail(
                    user.getEmail(),
                    "🎉 Account Activated",
                    body,
                    null,
                    null,
                    null
            );

        } catch (Exception ex) {

        }
    }

    @Override
    public String login(String email, String password) {
        try {

            ActivationRequest activationRequest = activationRequestRepository.findByEmail(email)
                    .orElseThrow(() ->
                            new BusinessException(Constant.NOT_FOUND, MsgConstant.USER_NOT_FOUND));

            if (!activationRequest.getIsEmailVerified() || !activationRequest.getIsContactVerified()) {
                throw new BusinessException(Constant.UNAUTHORIZED,
                        MsgConstant.PLEASE_VERIFY_YOUR_EMAIL_FIRST);
            }

            if (!passwordEncoder.matches(password, activationRequest.getPassword())) {
                throw new BusinessException(Constant.UNAUTHORIZED, MsgConstant.INVALID_CREDENTIALS);
            }

            activationRequest.setLoginDate(new Timestamp(System.currentTimeMillis()));
            activationRequestRepository.save(activationRequest);

            PersonInfo person = activationRequest.getPersonInfo();

            return jwtUtil.generateToken(
                    activationRequest.getEmail(),
                    person != null ? person.getId() : null,
                    person != null && person.getIsBasicDetailsSubmission()
            );

        } catch (BusinessException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new BusinessException(Constant.INTERNAL_SERVER_ERROR, "Error during login");
        }
    }

    @Override
    public void saveBasicDetails(BasicDetailsDTO basicDetailsDTO) {
        try {

            String email = (String) SecurityContextHolder
                    .getContext()
                    .getAuthentication()
                    .getPrincipal();

            ActivationRequest user = activationRequestRepository.findByEmail(email)
                    .orElseThrow(() ->
                            new BusinessException(Constant.NOT_FOUND, MsgConstant.USER_NOT_FOUND));

            PersonInfo person = user.getPersonInfo();

            if (person == null) {
                throw new BusinessException(Constant.BAD_REQUEST, "Person not created yet");
            }

            PersonBasicDetails basic = new PersonBasicDetails();
            basic.setFirstName(basicDetailsDTO.getFirstName());
            basic.setLastName(basicDetailsDTO.getLastName());
            basic.setMiddleName(basicDetailsDTO.getMiddleName());
            basic.setAadhaarCard(basicDetailsDTO.getAadhaar());
            basic.setEmail(user.getEmail());
            basic.setContact(user.getContact());
            basic.setStatus(basicDetailsDTO.getStatus());
            basic.setEmployeeId(basicDetailsDTO.getEmployeeId());
            basic.setBasicDetailsSubmission(true);

            basic.setPersonInfo(person);
            person.setBasicDetails(basic);

            personBasicDetailsRepository.save(basic);

            person.setPersonId(basic.getId());
            person.setFirstName(basicDetailsDTO.getFirstName());
            person.setLastName(basicDetailsDTO.getLastName());
            person.setEmployeeId(basicDetailsDTO.getEmployeeId());
            person.setIsBasicDetailsSubmission(true);

            personInfoRepository.save(person);

        } catch (BusinessException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new BusinessException(Constant.INTERNAL_SERVER_ERROR, "Error saving basic details");
        }
    }

    @Override
    public ProfileResponseDTO getProfile() {
        try {

            String email = (String) SecurityContextHolder
                    .getContext()
                    .getAuthentication()
                    .getPrincipal();

            ActivationRequest user = activationRequestRepository.findByEmail(email)
                    .orElseThrow(() ->
                            new BusinessException(Constant.NOT_FOUND, MsgConstant.USER_NOT_FOUND));

            PersonInfo person = user.getPersonInfo();

            ProfileResponseDTO response = new ProfileResponseDTO();

            response.setEmail(user.getEmail());
            response.setContact(user.getContact());
            response.setEmailVerified(user.getIsEmailVerified());
            response.setContactVerified(user.getIsContactVerified());

            if (person != null) {

                response.setBasicDetailsSubmitted(
                        person.getIsBasicDetailsSubmission());

                PersonBasicDetails basic = person.getBasicDetails();

                if (basic != null) {
                    response.setFirstName(basic.getFirstName());
                    response.setLastName(basic.getLastName());
                    response.setMiddleName(basic.getMiddleName());
                    response.setEmployeeId(basic.getEmployeeId());
                    response.setStatus(basic.getStatus());
                }
            }

            return response;

        } catch (BusinessException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new BusinessException(Constant.INTERNAL_SERVER_ERROR, "Error fetching profile");
        }
    }

    private String buildOtpEmail(String name, String otp) {
        return String.format("""
    <html>
    <body style="margin:0;padding:0;background:#f4f6f8;font-family:Arial">

        <div style="max-width:500px;margin:40px auto;background:#ffffff;
                    border-radius:12px;padding:30px;text-align:center;
                    box-shadow:0 5px 15px rgba(0,0,0,0.1);">

            <h2 style="color:#4CAF50;">🔐 OTP Verification</h2>

            <p>Hello <b>%s</b>,</p>

            <p>Your OTP is:</p>

            <div style="margin:25px 0;">
                <span style="font-size:30px;font-weight:bold;
                             letter-spacing:6px;
                             background:#f1f1f1;
                             padding:15px 25px;
                             border-radius:8px;">
                    %s
                </span>
            </div>

            <p>Valid for 5 minutes</p>

        </div>

    </body>
    </html>
    """, name, otp);
    }

    @Override
    public String refreshToken(String authHeader) {
        try {
            return jwtUtil.refreshToken(authHeader);
        } catch (Exception ex) {
            throw new BusinessException(Constant.UNAUTHORIZED, "Token refresh failed");
        }
    }

    @Override
    public void generateResetPasswordURL(String data) {

        ActivationRequest user = activationRequestRepository
                .findByEmailOrContact(data)
                .orElseThrow(() ->
                        new BusinessException(Constant.NOT_FOUND, "Account does not exist"));

        String resetToken;
        String resetLink;


        if (data.matches("^\\+?91?\\d{10}$")) {

            String contact = data.startsWith("+91") ? data : "+91" + data;

            resetToken = jwtUtil.generateResetToken(contact);
            resetLink = "http://localhost:3000/reset-password?token=" + resetToken;


            twilioService.sendMobileOtp(contact, "Reset Password: " + resetLink);

        } else {

            resetToken = jwtUtil.generateResetToken(user.getEmail());
            resetLink = "http://localhost:3000/reset-password?token=" + resetToken;


            String emailBody = String.format("""
        <html>
        <body style="font-family:Arial;background:#f4f6f8;padding:20px;">

            <div style="max-width:500px;margin:auto;background:#fff;padding:20px;border-radius:10px;">
                
                <h2 style="color:#4CAF50;text-align:center;">🔐 Reset Password</h2>
                
                <p>Hello <b>%s</b>,</p>
                
                <p>Click the button below to reset your password:</p>

                <div style="text-align:center;margin:20px;">
                    <a href="%s" 
                       style="background:#4CAF50;color:white;padding:10px 20px;
                              text-decoration:none;border-radius:5px;">
                        Reset Password
                    </a>
                </div>

                <p>Or copy this link:</p>
                <p style="word-break:break-all;">%s</p>

                <p style="color:red;">⚠ This link is valid for 15 minutes</p>

            </div>

        </body>
        </html>
        """, user.getEmail(), resetLink, resetLink);

            emailService.sendMail(
                    user.getEmail(),
                    "Reset Password",
                    emailBody,
                    null,
                    null,
                    null
            );
        }


        redisService.store(
                "RESET_TOKEN_" + user.getEmail(),
                resetToken,
                15,
                TimeUnit.MINUTES
        );
    }

    @Override
    public void updatePassword(String token, String newPassword) {

        try {
            String email = jwtUtil.extractEmailFromResetToken(token);

            if (email == null) {
                throw new BusinessException(Constant.UNAUTHORIZED, "Invalid token");
            }

            String storedToken = redisService.get("RESET_TOKEN_" + email);

            if (storedToken == null || !storedToken.equals(token)) {
                throw new BusinessException(Constant.UNAUTHORIZED, "Token expired or invalid");
            }

            ActivationRequest user = activationRequestRepository.findByEmail(email)
                    .orElseThrow(() ->
                            new BusinessException(Constant.NOT_FOUND, "User not found"));


            if (newPassword.length() < 6) {
                throw new BusinessException(Constant.BAD_REQUEST, "Password must be at least 6 characters");
            }

            user.setPassword(passwordEncoder.encode(newPassword));
            activationRequestRepository.save(user);

            redisService.clear("RESET_TOKEN_" + email);

        } catch (BusinessException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new BusinessException(Constant.UNAUTHORIZED, "Reset failed");
        }
    }

}