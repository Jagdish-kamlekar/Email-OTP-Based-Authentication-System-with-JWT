package com.example.emailotpverification.controller;

import com.example.emailotpverification.dto.ActivationRequestDTO;
import com.example.emailotpverification.dto.BasicDetailsDTO;
import com.example.emailotpverification.dto.LoginRequestDTO;
import com.example.emailotpverification.service.AuthService;
import com.example.emailotpverification.util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/sign-up")
    public ResponseEntity<ApiResponse<?>> register(@RequestBody ActivationRequestDTO activationRequestDTO) {
        return ResponseEntity.ok(ApiResponse.success(201, "Registered", authService.register(activationRequestDTO)));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<ApiResponse<?>> verify(@RequestBody ActivationRequestDTO activationRequestDTO) {
        return ResponseEntity.ok(ApiResponse.success(200, "Verified", authService.verifyOtp(activationRequestDTO)));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<?>> login(@RequestBody LoginRequestDTO loginRequestDTO) {
        String token = authService.login(loginRequestDTO.getEmail(), loginRequestDTO.getPassword());
        return ResponseEntity.ok(ApiResponse.success(200, "Login success", token));
    }

    @PostMapping("/basic-details")
    public ResponseEntity<ApiResponse<?>> saveBasicDetails(
            @RequestBody BasicDetailsDTO basicDetailsDTO) {

        authService.saveBasicDetails(basicDetailsDTO);

        return ResponseEntity.ok(
                ApiResponse.success(200, "Basic details saved", null)
        );
    }

    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<?>> getProfile() {

        return ResponseEntity.ok(
                ApiResponse.success(200, "Profile fetched", authService.getProfile())
        );
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<ApiResponse<?>> refreshToken(
            @RequestHeader("Authorization") String authHeader) {

        String token = authService.refreshToken(authHeader);

        return ResponseEntity.ok(
                ApiResponse.success(200, "Token refreshed", token)
        );
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<?>> forgotPassword(@RequestBody Map<String, String> body) {

        String data = body.get("data"); // email or mobile

        authService.generateResetPasswordURL(data);

        return ResponseEntity.ok(
                ApiResponse.success(200, "Reset link sent successfully", null)
        );
    }

    @PostMapping("/reset-password")
    public ResponseEntity<ApiResponse<?>> resetPassword(@RequestBody Map<String, String> body) {

        String token = body.get("token");
        String newPassword = body.get("newPassword");

        authService.updatePassword(token, newPassword);

        return ResponseEntity.ok(
                ApiResponse.success(200, "Password reset successful", null)
        );
    }

}