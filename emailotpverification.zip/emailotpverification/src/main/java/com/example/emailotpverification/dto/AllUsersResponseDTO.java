package com.example.emailotpverification.dto;

public class AllUsersResponseDTO {

    private String email;
    private String contact;
    private Long personInfoId;
    private Long basicDetailsId;
    private Boolean isBasicDetailsSubmission;

    public AllUsersResponseDTO() {}

    public AllUsersResponseDTO(String email, String contact,
                               Long personInfoId,
                               Long basicDetailsId,
                               Boolean isBasicDetailsSubmission) {
        this.email = email;
        this.contact = contact;
        this.personInfoId = personInfoId;
        this.basicDetailsId = basicDetailsId;
        this.isBasicDetailsSubmission = isBasicDetailsSubmission;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Long getPersonInfoId() {
        return personInfoId;
    }

    public void setPersonInfoId(Long personInfoId) {
        this.personInfoId = personInfoId;
    }

    public Long getBasicDetailsId() {
        return basicDetailsId;
    }

    public void setBasicDetailsId(Long basicDetailsId) {
        this.basicDetailsId = basicDetailsId;
    }

    public Boolean getBasicDetailsSubmission() {
        return isBasicDetailsSubmission;
    }

    public void setBasicDetailsSubmission(Boolean basicDetailsSubmission) {
        isBasicDetailsSubmission = basicDetailsSubmission;
    }
}