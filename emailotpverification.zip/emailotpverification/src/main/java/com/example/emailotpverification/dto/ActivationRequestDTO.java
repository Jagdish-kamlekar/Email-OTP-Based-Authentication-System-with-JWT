package com.example.emailotpverification.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;

public class ActivationRequestDTO {

    @NotNull(message = "Password is required")
    @NotBlank(message = "Password cannot be blank")
    @Size(min = 8, max = 20, message = "Password must be between 8 and 20 characters long")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$", message = "Password must contain at least one letter, one number, and one special character")
    private String password;

    @NotBlank(message = "Contact number cannot be blank")
    @Pattern(regexp = "\\d{10,15}", message = "Contact number must be 10 to 15 digits long")
    private String contact;

    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    private String email;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String emailOtp;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String contactOtp;

    private Boolean emailVerified;
    private Boolean contactVerified;

    private String jwtToken;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailOtp() {
        return emailOtp;
    }

    public void setEmailOtp(String emailOtp) {
        this.emailOtp = emailOtp;
    }

    public String getContactOtp() {
        return contactOtp;
    }

    public void setContactOtp(String contactOtp) {
        this.contactOtp = contactOtp;
    }

    public Boolean getEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(Boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    public Boolean getContactVerified() {
        return contactVerified;
    }

    public void setContactVerified(Boolean contactVerified) {
        this.contactVerified = contactVerified;
    }

    public String getJwtToken() {
        return jwtToken;
    }

    public void setJwtToken(String jwtToken) {
        this.jwtToken = jwtToken;
    }
}