package com.example.emailotpverification.repository;

import com.example.emailotpverification.entity.PersonBasicDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonBasicDetailsRepository extends JpaRepository<PersonBasicDetails, Long> {
}