package com.example.emailotpverification.config;

import com.twilio.Twilio;
import jakarta.annotation.PostConstruct;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TwilioInitializer {

    private static final Log logger = LogFactory.getLog(TwilioInitializer.class);

    @Value("${twilio.account-sid}")
    private String accountSid;

    @Value("${twilio.auth-token}")
    private String authToken;

    @Value("${twilio.from-number}")
    private String fromNumber;

    @PostConstruct
    public void init() {
        logger.info("Twilio SID  = [" + accountSid + "]");
        logger.info("Twilio FROM = [" + fromNumber + "]");
        Twilio.init(accountSid, authToken);
    }
}
