package com.example.emailotpverification.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "mst_person_basic_details")
public class PersonBasicDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "middle_name")
    private String middleName;

    @Column
    private String email;

    @Column
    private String contact;

    @Column
    private Integer status;

    @Column(name = "aadhaar_card")
    private String aadhaarCard;

    @Column(name = "is_basic_details_submission")
    private Boolean isBasicDetailsSubmission = false;

    @Column(name = "employee_id")
    private String employeeId;

    @OneToOne
    @JoinColumn(name = "person_info_id")
    private PersonInfo personInfo;

    public PersonBasicDetails() {
    }

    public PersonBasicDetails(Long id, String firstName, String lastName, String middleName, String email, String contact, Integer status, String aadhaarCard, Boolean isBasicDetailsSubmission, String employeeId, PersonInfo personInfo) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.email = email;
        this.contact = contact;
        this.status = status;
        this.aadhaarCard = aadhaarCard;
        this.isBasicDetailsSubmission = isBasicDetailsSubmission;
        this.employeeId = employeeId;
        this.personInfo = personInfo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getAadhaarCard() {
        return aadhaarCard;
    }

    public void setAadhaarCard(String aadhaarCard) {
        this.aadhaarCard = aadhaarCard;
    }

    public Boolean getBasicDetailsSubmission() {
        return isBasicDetailsSubmission;
    }

    public void setBasicDetailsSubmission(Boolean basicDetailsSubmission) {
        isBasicDetailsSubmission = basicDetailsSubmission;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public PersonInfo getPersonInfo() {
        return personInfo;
    }

    public void setPersonInfo(PersonInfo personInfo) {
        this.personInfo = personInfo;
    }

}