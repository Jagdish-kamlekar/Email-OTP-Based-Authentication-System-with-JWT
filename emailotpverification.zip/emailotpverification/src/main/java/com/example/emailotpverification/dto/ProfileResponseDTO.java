package com.example.emailotpverification.dto;

public class ProfileResponseDTO {

    private String email;
    private String contact;

    private Boolean emailVerified;
    private Boolean contactVerified;

    private String firstName;
    private String lastName;
    private String middleName;

    private String employeeId;
    private Integer status;

    private Boolean basicDetailsSubmitted;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Boolean getEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(Boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    public Boolean getContactVerified() {
        return contactVerified;
    }

    public void setContactVerified(Boolean contactVerified) {
        this.contactVerified = contactVerified;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Boolean getBasicDetailsSubmitted() {
        return basicDetailsSubmitted;
    }

    public void setBasicDetailsSubmitted(Boolean basicDetailsSubmitted) {
        this.basicDetailsSubmitted = basicDetailsSubmitted;
    }

}