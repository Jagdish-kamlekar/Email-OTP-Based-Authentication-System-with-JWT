package com.example.emailotpverification.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    private static final long EXPIRATION_TIME = 1000 * 60 * 1; // 1 minutes
    private static final long RESET_EXPIRATION = 1000 * 60 * 15; // 15 minutes

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String generateToken(String email, Long personId, Boolean isBasicDetailsSubmitted) {

        return Jwts.builder()
                .claim("email", email)
                .claim("personId", personId)
                .claim("isBasicDetailsSubmitted", isBasicDetailsSubmitted)
                .setSubject(email)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(getSigningKey())
                .compact();
    }

    public String generateResetToken(String email) {
        return Jwts.builder()
                .claim("email", email)
                .setSubject(email)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + RESET_EXPIRATION))
                .signWith(getSigningKey())
                .compact();
    }


    public String extractEmail(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public Long extractPersonId(String token) {
        return extractAllClaims(token).get("personId", Long.class);
    }

    public Boolean isBasicDetailsSubmitted(String token) {
        return extractAllClaims(token).get("isBasicDetailsSubmitted", Boolean.class);
    }

    public Map<String, Object> extractAllData(String token) {
        Claims claims = extractAllClaims(token);
        Map<String, Object> data = new HashMap<>();

        for (String key : claims.keySet()) {
            data.put(key, claims.get(key));
        }

        return data;
    }

    public boolean validateToken(String token, String email) {
        try {
            final String extractedEmail = extractEmail(token);
            return (extractedEmail.equals(email) && !isTokenExpired(token));
        } catch (Exception ex) {
            return false;
        }
    }


    private Claims extractAllClaims(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (ExpiredJwtException ex) {
            return ex.getClaims();
        }
    }

    private <T> T extractClaim(String token, Function<Claims, T> resolver) {
        return resolver.apply(extractAllClaims(token));
    }

    private boolean isTokenExpired(String token) {
        try {
            return extractClaim(token, Claims::getExpiration).before(new Date());
        } catch (Exception ex) {
            return true;
        }
    }

    public String refreshToken(String authHeader) {

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new RuntimeException("Invalid Authorization header");
        }

        String token = authHeader.substring(7);

        String email = extractEmail(token);
        Long personId = extractPersonId(token);
        Boolean isBasicDetailsSubmitted = isBasicDetailsSubmitted(token);

        return generateToken(email, personId, isBasicDetailsSubmitted);
    }

    public String extractEmailFromResetToken(String token) {
        return extractClaim(token, Claims::getSubject);
    }
}